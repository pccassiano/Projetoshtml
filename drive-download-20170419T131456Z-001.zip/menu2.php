<!DOCTYPE html>
<html lang="en">
<head>
  <title>Seraph Web Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/material.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/compiled.min.css">
  <script src="scripts/material.min.js"></script>
  <script src="scripts/compiled.min.js"></script>
  <script src="scripts/jquery.min.js"></script>
  
  
  
  <style>
.mdl-select {
          position: relative;
          font-size: 16px;
          display: inline-block;
          box-sizing: border-box;
          width: 300px;
          max-width: 100%;
          margin: 0;
          padding: 20px 0;
        }

        .mdl-select__input {
          border: none;
          border-bottom: 1px solid rgba(0,0,0, 0.12);
          display: inline-block;
          font-size: 16px;
          margin: 0;
          padding: 4px 0;
          width: 100%;
          background: 16px;
          text-align: left;
          color: inherit;
        }

        .mdl-select.is-focused .mdl-select__input {	outline: none; }
        .mdl-select.is-invalid .mdl-select__input { 
          border-color: rgb(222, 50, 38);
            box-shadow: none;
          }

        .mdl-select.is-disabled .mdl-select__input {
          background-color: transparent;
          border-bottom: 1px dotted rgba(0,0,0, 0.12);
        }

        .mdl-select__label {
          bottom: 0;
          color: rgba(0,0,0, 0.26);
          font-size: 16px;
          left: 0;
          right: 0;
          pointer-events: none;
          position: absolute;
          top: 24px;
          width: 100%;
          overflow: hidden;
          white-space: nowrap;
          text-align: left; 
        }

        .mdl-select.is-dirty .mdl-select__label { visibility: hidden; }

        .mdl-select--floating-label .mdl-textfield__label {
          -webkit-transition-duration: 0.2s;
          transition-duration: 0.2s;
          -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        }

        .mdl-select--floating-label.is-focused .mdl-select__label,
        .mdl-select--floating-label.is-dirty .mdl-select__label {
          color: rgb(63,81,181);
          font-size: 12px;
          top: 4px;
          visibility: visible;
        }

        .mdl-select--floating-label.is-focused .mdl-select__expandable-holder .mdl-select__label,
        .mdl-select--floating-label.is-dirty .mdl-select__expandable-holder .mdl-select__label {
          top: -16px;
        }

        .mdl-select--floating-label.is-invalid .mdl-select__label {
          color: rgb(222, 50, 38);
          font-size: 12px;
        }

        .mdl-select__label:after {
          background-color: rgb(63,81,181);
          bottom: 20px;
          content: '';
          height: 2px;
          left: 45%;
          position: absolute;
          -webkit-transition-duration: 0.2s;
          transition-duration: 0.2s;
          -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          visibility: hidden;
          width: 10px;
        }

        .mdl-select.is-focused .mdl-select__label:after {
          left: 0;
          visibility: visible;
          width: 100%; 
        }

        .mdl-select.is-invalid .mdl-select__label:after {
          background-color: rgb(222, 50, 38); 
        }

        .mdl-select__error {
          color: rgb(222, 50, 38);
          position: absolute;
          font-size: 12px;
          margin-top: 3px;
          visibility: hidden;
        }

        .mdl-select.is-invalid .mdl-select__error {
          visibility: visible;
        }

        .mdl-select__expandable-holder {
          display: inline-block;
          position: relative;
          margin-left: 32px;
          -webkit-transition-duration: 0.2s;
          transition-duration: 0.2s;
          -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          display: inline-block;
          max-width: 0.1px; 
        }

        .mdl-select.is-focused .mdl-select__expandable-holder, .mdl-select.is-dirty .mdl-select__expandable-holder {
          max-width: 600px; 
        }

        .mdl-select__expandable-holder .mdl-select__label:after {
          bottom: 0;
        }
  </style>
  <script>
   function MaterialSelect(element) {
  'use strict';

  this.element_ = element;
  this.maxRows = this.Constant_.NO_MAX_ROWS;
  // Initialize instance.
  this.init();
}

MaterialSelect.prototype.Constant_ = {
  NO_MAX_ROWS: -1,
  MAX_ROWS_ATTRIBUTE: 'maxrows'
};

MaterialSelect.prototype.CssClasses_ = {
  LABEL: 'mdl-textfield__label',
  INPUT: 'mdl-select__input',
  IS_DIRTY: 'is-dirty',
  IS_FOCUSED: 'is-focused',
  IS_DISABLED: 'is-disabled',
  IS_INVALID: 'is-invalid',
  IS_UPGRADED: 'is-upgraded'
};

MaterialSelect.prototype.onKeyDown_ = function(event) {
  'use strict';

  var currentRowCount = event.target.value.split('\n').length;
  if (event.keyCode === 13) {
    if (currentRowCount >= this.maxRows) {
      event.preventDefault();
    }
  }
};

MaterialSelect.prototype.onFocus_ = function(event) {
  'use strict';

  this.element_.classList.add(this.CssClasses_.IS_FOCUSED);
};

MaterialSelect.prototype.onBlur_ = function(event) {
  'use strict';

  this.element_.classList.remove(this.CssClasses_.IS_FOCUSED);
};

MaterialSelect.prototype.updateClasses_ = function() {
  'use strict';
  this.checkDisabled();
  this.checkValidity();
  this.checkDirty();
};

MaterialSelect.prototype.checkDisabled = function() {
  'use strict';
  if (this.input_.disabled) {
    this.element_.classList.add(this.CssClasses_.IS_DISABLED);
  } else {
    this.element_.classList.remove(this.CssClasses_.IS_DISABLED);
  }
};

MaterialSelect.prototype.checkValidity = function() {
  'use strict';
  if (this.input_.validity.valid) {
    this.element_.classList.remove(this.CssClasses_.IS_INVALID);
  } else {
    this.element_.classList.add(this.CssClasses_.IS_INVALID);
  }
};

MaterialSelect.prototype.checkDirty = function() {
  'use strict';
  if (this.input_.value && this.input_.value.length > 0) {
    this.element_.classList.add(this.CssClasses_.IS_DIRTY);
  } else {
    this.element_.classList.remove(this.CssClasses_.IS_DIRTY);
  }
};

MaterialSelect.prototype.disable = function() {
  'use strict';

  this.input_.disabled = true;
  this.updateClasses_();
};

MaterialSelect.prototype.enable = function() {
  'use strict';

  this.input_.disabled = false;
  this.updateClasses_();
};

MaterialSelect.prototype.change = function(value) {
  'use strict';

  if (value) {
    this.input_.value = value;
  }
  this.updateClasses_();
};

MaterialSelect.prototype.init = function() {
  'use strict';

  if (this.element_) {
    this.label_ = this.element_.querySelector('.' + this.CssClasses_.LABEL);
    this.input_ = this.element_.querySelector('.' + this.CssClasses_.INPUT);

    if (this.input_) {
      if (this.input_.hasAttribute(this.Constant_.MAX_ROWS_ATTRIBUTE)) {
        this.maxRows = parseInt(this.input_.getAttribute(
            this.Constant_.MAX_ROWS_ATTRIBUTE), 10);
        if (isNaN(this.maxRows)) {
          this.maxRows = this.Constant_.NO_MAX_ROWS;
        }
      }

      this.boundUpdateClassesHandler = this.updateClasses_.bind(this);
      this.boundFocusHandler = this.onFocus_.bind(this);
      this.boundBlurHandler = this.onBlur_.bind(this);
      this.input_.addEventListener('input', this.boundUpdateClassesHandler);
      this.input_.addEventListener('focus', this.boundFocusHandler);
      this.input_.addEventListener('blur', this.boundBlurHandler);

      if (this.maxRows !== this.Constant_.NO_MAX_ROWS) {
        // TODO: This should handle pasting multi line text.
        // Currently doesn't.
        this.boundKeyDownHandler = this.onKeyDown_.bind(this);
        this.input_.addEventListener('keydown', this.boundKeyDownHandler);
      }

      this.updateClasses_();
      this.element_.classList.add(this.CssClasses_.IS_UPGRADED);
    }
  }
};

MaterialSelect.prototype.mdlDowngrade_ = function() {
  'use strict';
  this.input_.removeEventListener('input', this.boundUpdateClassesHandler);
  this.input_.removeEventListener('focus', this.boundFocusHandler);
  this.input_.removeEventListener('blur', this.boundBlurHandler);
  if (this.boundKeyDownHandler) {
    this.input_.removeEventListener('keydown', this.boundKeyDownHandler);
  }
};

// The component registers itself. It can assume componentHandler is available
// in the global scope.
componentHandler.register({
  constructor: MaterialSelect,
  classAsString: 'MaterialSelect',
  cssClass: 'mdl-js-select',
  widget: true
});
  
  </script>
</head>
<body>
	<div class="container-fluid"> 
        <!--
		<h1><table align="center"><tr><td><img src="images/seraph-tryouts-2.png"/></td></tr></table></h1>
		-->
        </div>
        <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
      <main class="mdl-layout__content">
        <div style='background-color:#fff;' class="mdl-tabs mdl-js-tabs">
            <div class="mdl-tabs__tab-bar">								
              <a href="#tab2-panel" style='color:#000;' class="mdl-tabs__tab">Admin Configuration</a> 
			  <a href="#tab3-panel" style='color:#000' class="mdl-tabs__tab">Network</a>
              <a href="#tab4-panel" style='color:#000' class="mdl-tabs__tab">Systems</a>
              <a href="#tab4-panel" style='color:#000' class="mdl-tabs__tab">Services</a>
              <a href="#tab1-panel" style='color:#000' class="mdl-tabs__tab is-active">About Seraph</a>
              <a href="#tab4-panel" style='color:#000' class="mdl-tabs__tab">Exit</a>
            </div>
            <div class="mdl-tabs__panel is-active" id="tab1-panel">

            </div>
			          
            <div class="mdl-tabs__panel" id="tab2-panel">

            </div>
            <div class="mdl-tabs__panel" id="tab3-panel">
                
            </div>
            <div class="mdl-tabs__panel" id="tab4-panel">
                
            </div>
        </div>
      </main>
    </div>
	
</body>
</html>
<!-- MDL Dropdown 2
			  <div class="dropdown">                
				<button class="btn btn-default dropdown-toggle waves-effect waves-light" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown default</button>
                                    <div class="dropdown-menu dropdown-default" aria-labelledby="dropdownMenu3" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Action</a>
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Another action</a>
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Something else here</a>
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Something else here</a>
                                    </div>
              
			  </div>
			  
			  			  <div class="dropdown">                
				<button class="btn btn-default dropdown-toggle waves-effect waves-light" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown default</button>
                                    <div class="dropdown-menu dropdown-default" aria-labelledby="dropdownMenu3" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Action</a>
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Another action</a>
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Something else here</a>
                                        <a class="dropdown-item" href="https://mdbootstrap.com/legacy/4.2.0/components/dropdowns#">Something else here</a>
                                    </div>
              
			  </div> 


-->
<!-- ======MDL Menu======

				<div class="container mdl-shadow--2dp">
						 <div class="bar">
							<div class="wrapper">     
							   <button id="demo_menu-lower-right" class="mdl-button mdl-js-button mdl-button--icon" data-upgraded=",MaterialButton">
								  <i class="material-icons">more_vert</i>
							   </button>
							   <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
								  for="demo_menu-lower-right">
								  <li class="mdl-menu__item">Item #1</li>
								  <li class="mdl-menu__item">Item #2</li>
								  <li disabled class="mdl-menu__item">Disabled Item</li>     
							   </ul>
							</div>
						 </div>
						 <div class="background"></div>
					  </div>
-->

<!--  ===========MDL Dropdown==========

<div class="mdl-select mdl-js-select mdl-select--floating-label">
        <select class="mdl-select__input" id="professsion" name="professsion">
          <option value=""></option>
          <option value="option1">option 1</option>
          <option value="option2">option 2</option>
          <option value="option3">option 3</option>
          <option value="option4">option 4</option>
          <option value="option5">option 5</option>
        </select>
        <label class="mdl-select__label" for="professsion">Profession</label>
-->


<!-- =========Previous Menu===========

<nav class="navbar navbar-inverse"> 
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Seraph <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Seraph-Sobre.php">Sobre o Projeto</a></li>
          <li><a href="Seraph-Wiki.php">Wiki</a></li>
          <li><a href="Seraph-FAQs.php">Duvidas Frequentes </a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Admin <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Admin-Geral.php">Visão Geral</a></li>
          <li><a href="Admin-Firewall.php">Firewall</a></li>
          <li><a href="Admin-LogsSistema.php">Logs do Sistema</a></li>
          <li><a href="Admin-LogsKernel.php">Logs do Kernel</a></li>
          <li><a href="Admin-Processos.php">Estado dos Processos</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Sistema <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Sistema-Administracao.php">Administração</a></li>
          <li><a href="Sistema-Cron.php">Tarefas Agendadas</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Rede <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Rede-Interfaces.php">Interfaces</a></li>
          <li><a href="Rede-Wifi.php">Wi-Fi</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Serviços <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Serviços-Samba.php">Samba - Compartilhamento de Arquivos</a></li>
          <li><a href="Serviços-OpenVPN.php">OpenVPN - Servidor/Cliente VPN</a></li>
          <li><a href="Serviços-Web.php">Servidor Web - Intranet</a></li>
        </ul>
      </li>  
         <li><a href="sair.php">Sair</a></li>
    </ul>
  </div>
</nav>
-->
