<!DOCTYPE html>
<html lang="en">
<head>
  <title>Seraph Web Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Admin Configuration <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Admin-Geral.php">Overview</a></li>
          <li><a href="Admin-Firewall.php">Firewall</a></li>
          <li><a href="LogSistema.php">System Logs</a></li>
          <li><a href="LogKernel.php">Kernel Logs</a></li>
          <li><a href="LogProcessos.php">Manage Active Processes</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">System<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Sistema-Administracao.php">Administration</a></li>
          <li><a href="Sistema-Cron.php">Task Scheduler</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Network <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Rede-Interfaces.php">Interfaces</a></li>
          <li><a href="Rede-Wifi.php">Wi-Fi</a></li>
	  <li><a href="LogRoute.php">Routes</a></li>

        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Services <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Serviços-Samba.php">Samba - File Sharing</a></li>
          <li><a href="Serviços-OpenVPN.php">OpenVPN - Client/Server VPN</a></li>
          <li><a href="Serviços-Web.php">Web Server - Intranet</a></li>
	  <li><a href="LogDHCP.php">DHCP Server</a></li>
	 </ul>
		      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About Seraph <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Seraph-Sobre.php">About the Project</a></li>
          <li><a href="Seraph-Wiki.php">Wiki</a></li>
          <li><a href="Seraph-FAQs.php">FAQ</a></li>
        </ul>
      </li>
      </li>  
         <li><a href="sair.php">Exit</a></li>
    </ul>
  </div>
</nav>

