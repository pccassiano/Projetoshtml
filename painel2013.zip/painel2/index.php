<?php
$local = "formulario_login.html";
header("Location: $local");

?>