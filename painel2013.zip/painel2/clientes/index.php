<?php
$redir = "../formulario_login.html";
header("Location: $redir");
?>