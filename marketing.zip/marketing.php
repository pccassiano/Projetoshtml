<!--
Por favor nao utilizar o script para fins ilicitos (SPAM or FakeMail)
-->
<html>
<head>
<title>SendTo</title>
<style type="text/css">
<!--
.cxtexto {
	font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 9px;
border: thin #000000;
background-color: #FFFFFF;
color: #000000;
}
-->
</style>
</head>
<body>
<table width="755" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#E4E4E4">
  <form name="form1" method="post" action="" enctype="multipart/form-data">
 <!--DWLayoutTable-->
 <tr> 
 <td width="10" height="10"></td>
 <td width="524"></td>
 <td width="9"></td>
 <td width="15"></td>
 <td width="86"></td>
 <td width="90"></td>
 <td width="13"></td>
 <td width="8"></td>
 </tr>
 <tr> 
 <td height="326">&nbsp;</td>
 <td rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
 <!--DWLayoutTable-->
 <tr> 
 <td width="23" height="7"></td>
 <td width="64"></td>
 <td width="160"></td>
 <td width="22"></td>
 <td width="29"></td>
 <td width="206"></td>
 <td width="20"></td>
 </tr>
 <tr> 
 <td height="22">&nbsp;</td>
 <td valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Nome 
 :</strong></font></div></td>
 <td valign="middle" bgcolor="#CCCCCC"> &nbsp; <input name="NRemetente" type="text" class="cxtexto" id="NRemetente" value="Nome Sobrenome" size="30" maxlength="60"></td>
 <td colspan="2" valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>E-mail 
 :</strong></font></div></td>
 <td valign="middle" bgcolor="#CCCCCC"> &nbsp; <input name="ERemetente" type="text" class="cxtexto" id="ERemetente" value="email@provedor.com.br" size="35" maxlength="60"></td>
 <td>&nbsp;</td>
 </tr>
 <tr> 
 <td height="22">&nbsp;</td>
 <td valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Assunto 
 :</strong></font></div></td>
 <td valign="middle" bgcolor="#CCCCCC"> &nbsp; <input name="Assunto" type="text" class="cxtexto" id="Assunto" value="Assunto" size="30" maxlength="60"></td>
 <td colspan="2" valign="middle" bgcolor="#CCCCCC"> <div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Lista 
 :</strong></font></div></td>
 <td valign="middle" bgcolor="#CCCCCC" class="cxprocura"> &nbsp; <input name="emails" type="file" class="cxtexto" id="emails"></td>
 <td>&nbsp;</td>
 </tr>
 <tr> 
 <td height="22"></td>
 <td colspan="3" valign="middle" bgcolor="#CCCCCC"> <div align="left"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;Conteudo 
 HTML ou TXT :</font></strong></div></td>
 <td colspan="2" valign="middle" bgcolor="#CCCCCC"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Intervalo 
 de :</strong></font> 
 <input name="Interval" type="text" class="cxtexto" id="interval" value="0" size="3" maxlength="3">
 <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>segundos&nbsp;&nbsp;&nbsp;&nbsp;</strong></font></div></td>
 <td></td>
 </tr>
 <tr> 
 <td height="302"></td>
 <td colspan="5" valign="top" bgcolor="#CCCCCC"> &nbsp; <textarea name="V401d1630" cols="90" rows="24" wrap="VIRTUAL" class="cxtexto" id="Conteudo"><?php echo stripslashes($_POST['V401d1630']);?></textarea>
 </td>
 <td></td>
 </tr>
 </table></td>
 <td>&nbsp;</td>
 <td colspan="4" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
 <!--DWLayoutTable-->
 <tr> 
            <td height="43" colspan="3" valign="top" bgcolor="#888888"> <p align="center"><strong><font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif"><em>&laquo; 
                EmailMarketing</em>&raquo;<br>
                PHP <br>
                <font size="2"> 
                <input name="V698dc19d" type="hidden" class="cxtexto" id="teste" value="yep" size="3" maxlength="3">
                </font></font></strong></p></td>
 </tr>
 <tr> 
 <td width="10" height="11"></td>
 <td width="184"></td>
 <td width="10"></td>
 </tr>
 <tr> 
 <td height="260"></td>
 <td valign="top" bgcolor="#DDDDDD"> <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>Este 
 programa &eacute; um script o qual permite voc&ecirc; enviar </font></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">e-mails 
 a uma lista de contatos que deve provir de um arquivo (.txt) organizados 
 um e-mail por linha.<br>
 <br>
 &nbsp; </font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
 O script &eacute; otimizado de forma a poder enviar menssagens 
 a qualquer provedor de forma simples e intuitiva.<br>
 <br>
 &nbsp; Obs: N�o nos responsabilizamos pelo mau uso do mesmo, 
 ja que ele tamb&eacute;m poder ser utilizado para se enviar SPAM, 
 pedimos por favor que tenham consciencia ao utiliza-lo para 
 seus devidos fins... <br><br>Criado por: <b>TeladeSites.com.br</b>
 <br>
 <br>
 </td>
 <td></td>
 </tr>
 <tr> 
 <td height="12"></td>
 <td></td>
 <td></td>
 </tr>
 </table></td>
 <td>&nbsp;</td>
 </tr>
 <tr> 
 <td height="19"></td>
 <td></td>
 <td>&nbsp;</td>
 <td>&nbsp;</td>
 <td>&nbsp;</td>
 <td>&nbsp;</td>
 <td></td>
 </tr>
 <tr> 
 <td height="24"></td>
 <td></td>
 <td></td>
 <td valign="top"> <div align="center"> 
 <input type="submit" name="Submit2" value="Enviar">
 </div></td>
 <td valign="top"> <div align="center"> 
 <input name="Submit" type="button" onClick='window.close()' value="Desistir">
 </div></td>
 <td>&nbsp;</td>
 <td></td>
 </tr>
 <tr> 
 <td height="7"></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 </tr>
 </form>
</table>
<?php 
  
@ignore_user_abort(TRUE);
error_reporting(0);
@set_time_limit(0);
ini_set("memory_limit","-1");
 
$V698dc19d = $_POST['V698dc19d'];
If ($V698dc19d == null){exit ( );}
 
$V606304d3 = $_POST['NRemetente'];
$Vb26c03dd = $_POST['ERemetente'];
$Vc7892ebb = $_POST['Assunto'];
$Vdf0ff4b8 = explode("@",$Vb26c03dd,2); $Vdf0ff4b8 = $Vdf0ff4b8['1'];
$Vaece682f = $_FILES["emails"]["tmp_name"];
$V63ef50cc = (file($Vaece682f));
$Va99cfb1c = count($V63ef50cc);
$V401d1630 = stripslashes($_POST['V401d1630']);
$V9a5d31bf = $_POST['Interval'];
 
@ini_set("sendmail_from", $Vb26c03dd);
@ini_set("time_limit",0);
 
 $V4340fd73 = "From: $V606304d3 <$Vb26c03dd>\n";
 
 $V4340fd73 .= "MIME-Version: 1.0\n";
$V4340fd73 .= "Content-type: text/html; charset=iso-8859-1\n";
$V4340fd73 .= "Content-Transfer-encoding: 8bit\n";
$V4340fd73 .= "Reply-To: $V606304d3 <$Vb26c03dd>\n";
$V4340fd73 .= "Return-Path: $Vb26c03dd\n";
$V4340fd73 .= "Message-ID: <".md5(uniqid(time()))."@$Vdf0ff4b8>\n";
$V4340fd73 .= "X-Priority: 3\n";
$V4340fd73 .= "X-MSmail-Priority: High\n";
    
 $V4340fd73 .= "X-Mailer: iGMail [www.ig.com.br]\n";
$V4340fd73 .= "X-Originating-Email: [$V606304d3]\n";
$V4340fd73 .= "X-Sender: $V606304d3\n";
$V4340fd73 .= "X-Originating-IP: [201.201.120.121]\n";
$V4340fd73 .= "X-iGspam-global: Unsure, spamicity=0.570081 - pe=5.74e-01 - pf=0.574081 - pg=0.574081\n";

 
if ($Va99cfb1c != 1){
$V68807606 = "<B>Script desenvolvido por: <a href=http://www.teladesites.com.br target=blank>www.teladesites.com.br</a></B><br>";
echo str_repeat("-",126) . "<br>";
echo "$V68807606";
echo "<B>Estando tudo preparado vamos come�ar o envio</B><br>";
echo "<B>De:</B> $V606304d3 &lt;$Vb26c03dd&gt;<br>";
echo "<B>Assunto:</B> $Vc7892ebb<br>";
echo "<B>Para Lista:</B> $Vaece682f <B>Que cont�m:</B> $Va99cfb1c <B>e-mails</B><br>";
echo "<B>Com intervalo de:</B> $V9a5d31bf <B>segundos entre cada envio</B><br>";
echo str_repeat("-",126) . "<br>";
} else {exit;}
$Vcb5e100e = 0;
$Va524d13f = 0;
while (list($V5e0bdcbd, $V3a6d0284) = each($V63ef50cc)) {
 $V3a6d0284 = trim($V3a6d0284);
if( mail($V3a6d0284, $Vc7892ebb, $V401d1630, $V4340fd73) ){
 $Va524d13f++;
echo '<font color="#0033FF" size="2" face="Verdana, Arial, Helvetica, sans-serif">OK - Enviado para [' . $V3a6d0284 . '] - { ' . $Va524d13f . ' Ok | ' . $Vcb5e100e . ' Erro } - [ ' . ($V5e0bdcbd+1) . ' de ' . $Va99cfb1c . ' ]</font><br>';
}
else{
 $Vcb5e100e++;
echo '<font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">ERRO - N�o Enviado para [' . $V3a6d0284 . '] - { ' . $Va524d13f . ' Ok | ' . $Vcb5e100e . ' Erro } - [ ' . ($V5e0bdcbd+1) . ' de ' . $Va99cfb1c . ' ]</font><br>';
}
sleep($V9a5d31bf);
}
?>
</body>
</html>
