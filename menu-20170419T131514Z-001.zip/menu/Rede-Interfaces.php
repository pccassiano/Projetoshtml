<?php
include '../menu.php';
echo "<link rel='stylesheet' href='../css/bootstrap.min_alt.css'>
  <script src='../scripts/jquery.min.js'></script>
  <script src='../scripts/bootstrap.min.js'></script>
";
$lines = explode("\n",shell_exec('ifconfig'));
foreach($lines as $line)echo $line."<BR>";
echo"</body></html>";

?>
