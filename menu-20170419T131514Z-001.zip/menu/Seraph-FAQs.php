<?php
include 'menu.php';
?>

    <div class="col-sm-10 col-sm-offset-1">
<h2> O que é o Seraph</h2>
<p>Seraph é um projeto com a ideia de simplificar a implementação dos princiais serviços de rede em uma rede de pequeno porte </p>
  </div>