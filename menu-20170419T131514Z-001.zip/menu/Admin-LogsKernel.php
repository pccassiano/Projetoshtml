<?php
include 'menu.php';
?>

<style>
pre{
height:500px;/*defina a altura que você quiser*/
white-space: pre-line; 
overflow:auto;
}
</style>
 <div class="container">
   <h2>Logs Kernel</h2>
    
<?php
$output = shell_exec('dmesg');
echo "<pre>$output</pre>";  
?> 
  
</div>

    