<?php
include 'menu.php';
?>

  <div class="container">
<h2>OpenVPN</h2>
    <h3> Modo Server </h3>
    <h3> Modo Cliente </h3>
    
  </div>