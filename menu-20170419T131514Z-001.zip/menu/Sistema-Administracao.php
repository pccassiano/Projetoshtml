<?php
include 'menu.php';
?>

<div class="container">
  <h2>Administração  </h2>
  <p>Pagina destinada a configurações basicas administrativas</p>
  <form>
    <div class="input-group col-sm-3">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="senha" placeholder="Senha">
    </div>
    <div class="input-group col-sm-3">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="senha" placeholder="Confirmar Senha">
    </div>
     <div class="input-group col-sm-3">
     <button type="submit" class="btn btn-default center-block">Alterar Senha</button>
    </div>
  </form>
</div>

</body>
</html>
