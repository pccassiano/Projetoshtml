<?php
include '../menu.php';
foreach (glob("../../model/*.php") as $filename)
{
    include $filename;
}
echo "<link rel='stylesheet' href='/TCC/css/bootstrap.min_alt.css'>
  <script src='/TCC/scripts/jquery.min.js'></script>
  <script src='/TCC/scripts/bootstrap.min.js'></script>
";
$config = new InterfaceConfig();
$config->showConfig();
echo "<br>";
$config->changeConfig();
$config->showConfig();
?>
