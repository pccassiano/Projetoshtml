<?php
echo round(memory_get_usage() / 1024, 4), 'Kb', PHP_EOL; 

$output = shell_exec('sudo /var/www/co.gustavofernandes.com.br/public_html/shell/teste.sh');
echo "<pre>$output</pre>";  


$string = 'f@tec1234';
$codificada = hash('sha512', $string);
echo "Resultado da codificação usando sha512: " . $codificada;



php -a

  ?>

