<?php
include 'menu.php';
?>

  <div class="container">
<h2>Servidor de Compartilhamento de Arquivos Samba</h2>
  </div>