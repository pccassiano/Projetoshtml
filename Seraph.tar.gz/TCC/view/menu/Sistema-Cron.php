<?php
include 'menu.php';
?>

<div class="container">
  <h2>Cron - Tarefas Agendadas</h2>
  <p>Digite a tarefa abaixo e clique em salvar</p>
  <form>
    <div class="form-group">
      <label for="comment">Comment:</label>
      <textarea class="form-control" rows="5" id="comment"></textarea>
    </div>
     <button type="submit" class="btn btn-default">Atualizar</button>
  </form>
</div>

</body>
</html>
