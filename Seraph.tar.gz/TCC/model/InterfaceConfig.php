<?php
class InterfaceConfig{

	public $test = "TestingString";

	public function showConfig(){
		$lines = explode("\n",shell_exec('ifconfig'));
		foreach($lines as $line)echo $line."<BR>";
		echo"</body></html>";
	}
	public function changeConfig(){

//	if(!empty($configurationsettings['lanip'])) {
//	logmessage("Reconfiguring ip value for interface br0.");
//	logmessage("Flushing existing ip addresses for interface br0.");
//	shell_exec("sudo ip addr flush dev br0 2>&1 | sudo tee --append /var/log/raspberrywap.log");
//	logmessage("Adding static ip address to interface br0.");
//	shell_exec("sudo ip addr add " . $configurationsettings['lanip'] . "/" . mask2cidr($configurationsettings['lanmask']) . " broadcast " . cidr2broadcast($configurationsettings['lanip'], mask2cidr($configurationsettings['lanmask'])) . " dev br0 2>&1 | sudo tee --append /var/log/raspberrywap.log");
//	}
//	else {
//	logmessage("Reconfiguring ip value for interface br0 - no value found, setting default value 192.168.2.1/24");
//	logmessage("Flushing existing ip addresses for interface br0.");
	shell_exec("sudo ip addr flush dev br0 2>&1 | sudo tee --append /var/log/raspberrywap.log");
//	logmessage("Adding default static ip address to interface br0.");
	shell_exec("sudo ip addr add 192.168.2.1/24 broadcast 192.168.2.255 dev br0 2>&1 | /sudo tee --append /var/log/raspberrywap.log");
//	}
	}

}
?>
